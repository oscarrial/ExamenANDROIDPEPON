package com.example.a016gettingresults;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SecondActivity extends AppCompatActivity {

    TextView cadena;
    TextView resultado;
    TextView cadena2;
    Button boton;
    Button boton2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_second);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        cadena = findViewById(R.id.textView3);
        cadena2 = findViewById(R.id.textView2);
        resultado = findViewById(R.id.sale);
        boton = findViewById(R.id.invertir);
        boton2 = findViewById(R.id.volver);
        boton.setOnClickListener(this::invertir);
        boton2.setOnClickListener(this::volver);
        cadena.setText(getIntent().getStringExtra(Intent.EXTRA_TEXT));




    }

    private void volver(View v) {
        Intent returnIntent = new Intent();
        returnIntent.putExtra(MainActivity.REQUEST_RESULT, resultado.getText().toString());
        setResult(RESULT_OK, returnIntent);
        //necesitamos una llamada al metodo finish para que se cierre la actividad
        finish();
    }

    private void invertir(View v) {
        String cadena1 = cadena.getText().toString();
        String cadena3 = "";
        for (int i = cadena1.length() - 1; i >= 0; i--) {
            cadena3 += cadena1.charAt(i);
        }
        resultado.setText(cadena3);

    }
}